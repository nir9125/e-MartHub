import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable, Subscriber } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { ProductService } from 'src/app/services/product.service';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html', // Update this with your actual template URL
  styleUrls: ['./add-product.component.css'] // Update this with your actual styles URL
})
export class AddProductComponent{

  product: any = {};
  productList: any[] = [];
  selectedImage: File | null = null;

  constructor(private productService: ProductService) {
    
   }

  ngOnInit(): void {
    this.fetchProducts();
  }
  fetchProducts() {
    let m = localStorage.getItem('smail')
    this.productService.getProductsBySellerMailId(m).subscribe(
      (response) => {
        this.productList = response;
      },
      (error) => {
        console.error('Error fetching products', error);
      }
    );
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.selectedImage || ''); // Append the selected image file if available
    formData.append('product', JSON.stringify(this.product)); // Append the other form data as JSON

    this.productService.addProduct(formData).subscribe(
      (response) => {
        console.log('Product added successfully', response);
        this.product = {};
        this.selectedImage = null;
      },
      (error) => {
        console.error('Error adding product', error);
      }
    );

      let m = localStorage.getItem('smail')
      console.log(m);
    this.productService.getProductsBySellerMailId(m).subscribe(
      (response) => {
        console.log(response)
        this.productList = response;
      },
      (error) => {
        console.error('Error fetching products', error);
      }
    );
  }

  onImageChange(event: any) {
    this.selectedImage = event.target.files[0];
  }


}
